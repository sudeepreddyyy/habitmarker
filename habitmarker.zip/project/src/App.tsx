import React, { useState, useEffect } from 'react';
import { PlusCircle, X, Edit2, Trash2, Sun, Moon, Trash, AlertCircle } from 'lucide-react';

interface Habit {
  id: string;
  name: string;
  duration: number;
  startDate: string;
  progress: boolean[];
  isDeleted: boolean;
}

function App() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [newHabitName, setNewHabitName] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [habitToDelete, setHabitToDelete] = useState<string | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<number>(21);
  const [customDuration, setCustomDuration] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'current' | 'deleted' | 'add'>('current');
  const [editingHabit, setEditingHabit] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('darkMode') === 'true';
    }
    return false;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('darkMode', darkMode.toString());
      if (darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const addHabit = (duration?: number) => {
    if (newHabitName.trim()) {
      const finalDuration = duration || selectedDuration;
      const newHabit: Habit = {
        id: Date.now().toString(),
        name: newHabitName,
        duration: finalDuration,
        startDate: new Date().toISOString(),
        progress: Array(finalDuration).fill(false),
        isDeleted: false
      };
      setHabits([...habits, newHabit]);
      setNewHabitName('');
      setShowAddModal(false);
      setCustomDuration('');
      setActiveTab('current');
    }
  };

  const toggleProgress = (habitId: string, index: number) => {
    setHabits(habits.map(habit => {
      if (habit.id === habitId) {
        const newProgress = [...habit.progress];
        newProgress[index] = !newProgress[index];
        return { ...habit, progress: newProgress };
      }
      return habit;
    }));
  };

  const confirmDelete = (habitId: string) => {
    setHabitToDelete(habitId);
    setShowDeleteModal(true);
  };

  const deleteHabit = () => {
    if (habitToDelete) {
      setHabits(habits.map(habit => 
        habit.id === habitToDelete ? { ...habit, isDeleted: true } : habit
      ));
      setShowDeleteModal(false);
      setHabitToDelete(null);
    }
  };

  const clearDeletedHabits = () => {
    setHabits(habits.filter(habit => !habit.isDeleted));
  };

  const updateHabitName = (habitId: string, newName: string) => {
    setHabits(habits.map(habit =>
      habit.id === habitId ? { ...habit, name: newName } : habit
    ));
    setEditingHabit(null);
  };

  const getProgressCount = (progress: boolean[]) => {
    return `${progress.filter(Boolean).length}/${progress.length}`;
  };

  const handleCustomDurationSubmit = () => {
    const duration = parseInt(customDuration);
    if (duration > 0) {
      addHabit(duration);
    }
  };

  const currentHabits = habits.filter(habit => !habit.isDeleted);
  const deletedHabits = habits.filter(habit => habit.isDeleted);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
      <div className="max-w-4xl mx-auto p-8">
        <div className="flex items-center justify-between mb-8">
          <img
            src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/habit-marker-logo.png"
            alt="Habit Marker Logo"
            className="w-12 h-12"
          />
          <div className="text-center flex-1">
            <h1 className={`text-3xl font-bold mb-1 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              Habit Marker
            </h1>
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Track your habits here
            </p>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-full transition-colors duration-300 ${
              darkMode ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            {darkMode ? <Sun size={24} /> : <Moon size={24} />}
          </button>
        </div>
        
        {/* Tabs */}
        <div className="flex justify-center gap-4 mb-8">
          <button
            className={`px-4 py-2 rounded-lg transition-colors duration-300 ${
              activeTab === 'current' 
                ? 'bg-blue-500 text-white' 
                : `${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-white text-gray-800'}`
            }`}
            onClick={() => setActiveTab('current')}
          >
            Current Habits
          </button>
          <button
            className={`px-4 py-2 rounded-lg transition-colors duration-300 ${
              activeTab === 'deleted' 
                ? 'bg-blue-500 text-white' 
                : `${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-white text-gray-800'}`
            }`}
            onClick={() => setActiveTab('deleted')}
          >
            Deleted Habits
          </button>
          <button
            className={`px-4 py-2 rounded-lg transition-colors duration-300 ${
              activeTab === 'add' 
                ? 'bg-blue-500 text-white' 
                : `${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-white text-gray-800'}`
            }`}
            onClick={() => setActiveTab('add')}
          >
            Add New Habit
          </button>
        </div>

        {/* Add Habit Form */}
        {activeTab === 'add' && (
          <div className={`p-6 rounded-lg shadow-md mb-8 transition-colors duration-300 ${
            darkMode ? 'bg-gray-800' : 'bg-white'
          }`}>
            <div className="flex gap-4 mb-4">
              <input
                type="text"
                value={newHabitName}
                onChange={(e) => setNewHabitName(e.target.value)}
                placeholder="Enter habit name..."
                className={`flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-300 ${
                  darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-800'
                }`}
              />
              <button
                onClick={() => setShowAddModal(true)}
                className="bg-blue-500 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-600 transition-colors duration-300"
              >
                <PlusCircle size={20} /> Add
              </button>
            </div>
          </div>
        )}

        {/* Duration Selection Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center backdrop-blur-sm">
            <div className={`p-6 rounded-lg w-96 transition-colors duration-300 ${
              darkMode ? 'bg-gray-800' : 'bg-white'
            }`}>
              <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Select Tracking Duration
              </h2>
              <div className="space-y-4">
                <button
                  onClick={() => {
                    setSelectedDuration(21);
                    addHabit();
                  }}
                  className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-300"
                >
                  21 Days
                </button>
                <button
                  onClick={() => {
                    setSelectedDuration(30);
                    addHabit();
                  }}
                  className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-300"
                >
                  30 Days
                </button>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={customDuration}
                    onChange={(e) => setCustomDuration(e.target.value)}
                    placeholder="Enter custom days..."
                    className={`flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-300 ${
                      darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-800'
                    }`}
                  />
                  <button
                    onClick={handleCustomDurationSubmit}
                    className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-300"
                  >
                    Set
                  </button>
                </div>
                <button
                  onClick={() => setShowAddModal(false)}
                  className={`w-full px-4 py-2 rounded-lg transition-colors duration-300 ${
                    darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-300 text-gray-700'
                  } hover:opacity-90`}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {showDeleteModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center backdrop-blur-sm">
            <div className={`p-6 rounded-lg w-96 transition-colors duration-300 ${
              darkMode ? 'bg-gray-800' : 'bg-white'
            }`}>
              <div className="flex items-center gap-3 mb-4">
                <AlertCircle className="text-red-500" size={24} />
                <h2 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                  Delete Habit
                </h2>
              </div>
              <p className={`mb-6 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                Are you sure you want to delete this habit? This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={deleteHabit}
                  className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors duration-300"
                >
                  Yes, Delete
                </button>
                <button
                  onClick={() => {
                    setShowDeleteModal(false);
                    setHabitToDelete(null);
                  }}
                  className={`flex-1 px-4 py-2 rounded-lg transition-colors duration-300 ${
                    darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-300 text-gray-700'
                  } hover:opacity-90`}
                >
                  No, Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Habits List */}
        {activeTab !== 'add' && (
          <div className="space-y-4">
            {activeTab === 'current' && currentHabits.length === 0 && (
              <div className={`text-center p-8 rounded-lg shadow-md transition-colors duration-300 ${
                darkMode ? 'bg-gray-800' : 'bg-white'
              }`}>
                <p className={`text-lg mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  Oh no, there are no current habits.
                </p>
                <button
                  onClick={() => setActiveTab('add')}
                  className="bg-blue-500 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-600 transition-colors duration-300 mx-auto"
                >
                  <PlusCircle size={20} /> Add New Habit
                </button>
              </div>
            )}
            {habits
              .filter(habit => habit.isDeleted === (activeTab === 'deleted'))
              .map(habit => (
                <div key={habit.id} className={`p-6 rounded-lg shadow-md transition-colors duration-300 ${
                  darkMode ? 'bg-gray-800' : 'bg-white'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    {editingHabit === habit.id ? (
                      <input
                        type="text"
                        value={habit.name}
                        onChange={(e) => updateHabitName(habit.id, e.target.value)}
                        onBlur={() => setEditingHabit(null)}
                        className={`px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-300 ${
                          darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-800'
                        }`}
                        autoFocus
                      />
                    ) : (
                      <h3 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                        {habit.name}
                      </h3>
                    )}
                    <div className="flex gap-2">
                      {!habit.isDeleted && (
                        <>
                          <button
                            onClick={() => setEditingHabit(habit.id)}
                            className={`p-2 rounded-full transition-colors duration-300 ${
                              darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                            }`}
                          >
                            <Edit2 size={20} className={darkMode ? 'text-gray-300' : 'text-gray-600'} />
                          </button>
                          <button
                            onClick={() => confirmDelete(habit.id)}
                            className={`p-2 rounded-full transition-colors duration-300 ${
                              darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                            }`}
                          >
                            <Trash2 size={20} className={darkMode ? 'text-gray-300' : 'text-gray-600'} />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                  {!habit.isDeleted && (
                    <div className="flex flex-wrap gap-2">
                      {habit.progress.map((done, index) => (
                        <button
                          key={index}
                          onClick={() => toggleProgress(habit.id, index)}
                          className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-medium transition-colors duration-300 ${
                            done 
                              ? 'bg-green-500 text-white' 
                              : `${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-800'}`
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                      <span className={`ml-4 flex items-center ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        {getProgressCount(habit.progress)}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            {activeTab === 'deleted' && habits.some(h => h.isDeleted) && (
              <button
                onClick={clearDeletedHabits}
                className={`mt-4 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors duration-300 ${
                  darkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                <Trash size={20} />
                Clear everything
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;